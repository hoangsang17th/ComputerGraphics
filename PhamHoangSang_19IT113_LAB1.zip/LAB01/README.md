# Những gì đạt được

    - Trong bài tập này em đã thực hiện ba bài toán vẽ đoạn thẳng, đường tròn, ellipse, và Parapol dựa trên  thuật toán Bressenham và Midpoint.
    - Em đã sử dụng thư viện matplotlib (yêu cầu phải cài đặt) để biểu diễn các thuật toán, tuy nhiên cách thức để vẽ bằng chuột vanac chưa tinh tế cho lắm. 

# Sự thiếu sót
    
    - Chưa cài đặt các thuật toán cho đường cong khác: hyperbol, sin(x), cos(x)